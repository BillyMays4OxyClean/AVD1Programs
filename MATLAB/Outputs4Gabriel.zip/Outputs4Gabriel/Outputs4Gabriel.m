%% Created by Luke Patterson for the Stability and Control outputs for Gabriel Reyes

clear
close all
clc

%% Flight Condition
% WK2 Cruises at 15200 meters at Mach 0.55
% The flight condition class definition will contain and calculate all
% values relating to atmospheric properties and airspeed

unitSystem = 'FPS';

Cruise = FlightCondition;
Cruise.Altitude = 50000; % <---- set Altitude in feet here
Cruise.AoA = 1.5; % <--- Set AoA here, Takeoff: 10, Climb: 5, Cruise: 1.5
Cruise.Units = unitSystem;
Cruise.Name = 'Cruise'; % <--- Name of the flight condition (optional)

Cruise = Cruise.SetSpeed("Mach",0.55); % <----- Set "Mach" or "V" here
Cruise = Cruise.ConvertUnits(unitSystem);

%% Geometry Definitions

MainWing = WingGeometry;
MainWing = MainWing.ImportFromCell(readcell('DataDump.xlsx','Sheet','MainWing'));
MainWing = MainWing.ConvertUnits(unitSystem);

HT = WingGeometry;
HT = HT.ImportFromCell(readcell('DataDump.xlsx','Sheet','HT'));
HT = HT.ConvertUnits(unitSystem);

VT = WingGeometry;
VT = VT.ImportFromCell(readcell('DataDump.xlsx','Sheet','VT'));
VT = VT.ConvertUnits(unitSystem);

Fuselage = FuselageGeometry;
Fuselage = Fuselage.ImportFromCell(readcell('DataDump.xlsx','Sheet','Fuselage'));
Fuselage = Fuselage.ConvertUnits(unitSystem);

SS2 = WingGeometry;
SS2.S = 47.63;
SS2.AR = 1.46;
SS2.Sweep = 45;
SS2.Rc = 28.2;
SS2.RootAirfoil = NACA4WingSection('0006',SS2.Rc,128);
SS2.Units = 'SI';
SS2 = SS2.ConvertUnits(unitSystem);


%% Aerodynamic Calculations
[CDMW,Dmw] = MainWing.ReturnDrag(Cruise);

[CDHT,Dht] = HT.ReturnDrag(Cruise);

[CDVT,Dvt] = VT.ReturnDrag(Cruise);

[CDfuse,Dfuse] = Fuselage.ReturnDrag(Cruise);

CD0SS2 = 0.0314;

[CLSS2,LSS2] = SS2.ReturnLift(Cruise);

CDLSS2 = CLSS2^2/(pi*SS2.AR*SS2.RootAirfoil.e);

CDSS2 = CD0SS2 + CDLSS2;

DSS2 = Cruise.AirSpeed.q*CDSS2*SS2.S;

CD =  CDMW + 2*CDfuse + 2*CDHT + 2*CDVT + CDSS2;

D = Dmw + 2*Dfuse + 2*Dht + 2*Dvt + DSS2;

[Clmw,Lmw] = MainWing.ReturnLift(Cruise);

[Clht,Lht] = HT.ReturnLift(Cruise);

[Clvt,Lvt] = VT.ReturnLift(Cruise);

CL = Clmw + 2*Clht + CLSS2; % Adding together the CL of the MW, HT, and SS2

L = Lmw + 2*Lht + 2*Lvt + LSS2;

if strcmp(unitSystem,'SI')
    unit = 'N';
elseif strcmp(unitSystem,'FPS')
    unit = 'lbf';
end

fprintf('Total Vehicle Section Lift coefficient during %s is %.2f\n',Cruise.Name,CL)